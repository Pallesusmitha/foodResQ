import 'package:ResQFood/core/app_export.dart';

class ApiClient {}
