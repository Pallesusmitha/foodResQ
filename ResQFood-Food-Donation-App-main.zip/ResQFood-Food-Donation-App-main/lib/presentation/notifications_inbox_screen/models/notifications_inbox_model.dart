// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [notifications_inbox_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class NotificationsInboxModel extends Equatable {
  NotificationsInboxModel() {}

  NotificationsInboxModel copyWith() {
    return NotificationsInboxModel();
  }

  @override
  List<Object?> get props => [];
}
